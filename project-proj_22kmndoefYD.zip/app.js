class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Terjadi Kesalahan</h1>
            <button onClick={() => window.location.reload()} className="px-6 py-2 gradient-bg text-white rounded-lg">
              Muat Ulang
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const [orderModal, setOrderModal] = React.useState({ open: false, package: null });
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      setTimeout(() => setLoading(false), 500);
    }, []);

    return (
      <div className="min-h-screen bg-white" data-name="app" data-file="app.js">
        <Header loading={loading} />
        <Hero loading={loading} />
        <Services loading={loading} />
        <PricingSection loading={loading} onOrderClick={(pkgName) => setOrderModal({ open: true, package: { objectData: { Name: pkgName } } })} />
        <PortfolioSection loading={loading} />
        <Testimonials loading={loading} />
        <FloatingWhatsApp loading={loading} />
        <Footer loading={loading} />
        {orderModal.open && (
          <OrderModal 
            package={orderModal.package} 
            onClose={() => setOrderModal({ open: false, package: null })} 
          />
        )}
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);