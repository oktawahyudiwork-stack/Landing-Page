function FormModal({ type, item, onClose, onSave }) {
  try {
    const [formData, setFormData] = React.useState(item ? item.objectData : {});

    const handleSubmit = (e) => {
      e.preventDefault();
      onSave(formData);
    };

    const renderFields = () => {
      if (type === 'portfolio') {
        return (<>
          <input type="text" placeholder="Judul" required className="w-full px-4 py-2 border rounded-lg" value={formData.Title || ''} onChange={(e) => setFormData({...formData, Title: e.target.value})} />
          <input type="url" placeholder="URL Gambar" required className="w-full px-4 py-2 border rounded-lg" value={formData.Image || ''} onChange={(e) => setFormData({...formData, Image: e.target.value})} />
          <textarea placeholder="Deskripsi" required className="w-full px-4 py-2 border rounded-lg" rows="3" value={formData.Description || ''} onChange={(e) => setFormData({...formData, Description: e.target.value})}></textarea>
          <input type="url" placeholder="Link (optional)" className="w-full px-4 py-2 border rounded-lg" value={formData.Link || ''} onChange={(e) => setFormData({...formData, Link: e.target.value})} />
          <select className="w-full px-4 py-2 border rounded-lg" value={formData.Status || 'active'} onChange={(e) => setFormData({...formData, Status: e.target.value})}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </>);
      } else if (type === 'testimonial') {
        return (<>
          <input type="text" placeholder="Nama" required className="w-full px-4 py-2 border rounded-lg" value={formData.Name || ''} onChange={(e) => setFormData({...formData, Name: e.target.value})} />
          <input type="url" placeholder="URL Foto" className="w-full px-4 py-2 border rounded-lg" value={formData.Photo || ''} onChange={(e) => setFormData({...formData, Photo: e.target.value})} />
          <textarea placeholder="Testimoni" required className="w-full px-4 py-2 border rounded-lg" rows="4" value={formData.Content || ''} onChange={(e) => setFormData({...formData, Content: e.target.value})}></textarea>
          <select className="w-full px-4 py-2 border rounded-lg" value={formData.Status || 'active'} onChange={(e) => setFormData({...formData, Status: e.target.value})}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </>);
      } else if (type === 'package') {
        return (<>
          <input type="text" placeholder="Nama Paket" required className="w-full px-4 py-2 border rounded-lg" value={formData.Name || ''} onChange={(e) => setFormData({...formData, Name: e.target.value})} />
          <input type="text" placeholder="Harga" required className="w-full px-4 py-2 border rounded-lg" value={formData.Price || ''} onChange={(e) => setFormData({...formData, Price: e.target.value})} />
          <textarea placeholder="Deskripsi" required className="w-full px-4 py-2 border rounded-lg" rows="2" value={formData.Description || ''} onChange={(e) => setFormData({...formData, Description: e.target.value})}></textarea>
          <textarea placeholder="Features (pisah dengan koma)" required className="w-full px-4 py-2 border rounded-lg" rows="3" value={Array.isArray(formData.Features) ? formData.Features.join(',') : (formData.Features || '')} onChange={(e) => setFormData({...formData, Features: e.target.value.split(',').map(f => f.trim()).filter(f => f)})}></textarea>
          <select className="w-full px-4 py-2 border rounded-lg" value={formData.Status || 'active'} onChange={(e) => setFormData({...formData, Status: e.target.value})}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </>);
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className="bg-white rounded-xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
          <h3 className="text-xl font-bold mb-4">{item ? 'Edit' : 'Tambah'} {type}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            {renderFields()}
            <div className="flex space-x-3">
              <button type="submit" className="flex-1 py-2 gradient-bg text-white rounded-lg">Simpan</button>
              <button type="button" onClick={onClose} className="flex-1 py-2 bg-gray-200 rounded-lg">Batal</button>
            </div>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('FormModal error:', error);
    return null;
  }
}