function AdminHeader({ currentView, onNavigate }) {
  try {
    const menuItems = [
      { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
      { id: 'portfolio', label: 'Portfolio', icon: 'briefcase' },
      { id: 'testimonial', label: 'Testimoni', icon: 'message-square' },
      { id: 'package', label: 'Paket', icon: 'package' },
      { id: 'order', label: 'Order', icon: 'shopping-cart' }
    ];

    return (
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
            <a href="index.html" className="text-[var(--primary-color)] hover:underline">Lihat Website</a>
          </div>
          <nav className="flex space-x-4 overflow-x-auto">
            {menuItems.map(item => (
              <button key={item.id} onClick={() => onNavigate(item.id)} className={`flex items-center space-x-2 px-4 py-2 rounded-lg whitespace-nowrap ${currentView === item.id ? 'gradient-bg text-white' : 'bg-gray-100 text-gray-700'}`}>
                <div className={`icon-${item.icon}`}></div>
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </header>
    );
  } catch (error) {
    console.error('AdminHeader error:', error);
    return null;
  }
}