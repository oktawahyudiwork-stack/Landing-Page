function OrderManager() {
  try {
    const [items, setItems] = React.useState([]);

    React.useEffect(() => {
      loadItems();
    }, []);

    const loadItems = async () => {
      const result = await trickleListObjects('order', 100, true);
      setItems(result.items);
    };

    const handleDelete = async (id) => {
      if (confirm('Hapus order ini?')) {
        await trickleDeleteObject('order', id);
        loadItems();
      }
    };

    const handleMarkDone = async (item) => {
      await trickleUpdateObject('order', item.objectId, { ...item.objectData, Status: 'done' });
      loadItems();
    };

    return (
      <div>
        <h2 className="text-2xl font-bold mb-6">Order Management</h2>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left">Nama</th>
                <th className="px-6 py-3 text-left">Paket</th>
                <th className="px-6 py-3 text-left">WhatsApp</th>
                <th className="px-6 py-3 text-left">Status</th>
                <th className="px-6 py-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item.objectId} className="border-t">
                  <td className="px-6 py-4">{item.objectData.CustomerName}</td>
                  <td className="px-6 py-4">{item.objectData.PackageName}</td>
                  <td className="px-6 py-4">{item.objectData.WhatsApp}</td>
                  <td className="px-6 py-4"><span className={`px-2 py-1 rounded text-sm ${item.objectData.Status === 'done' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{item.objectData.Status}</span></td>
                  <td className="px-6 py-4 text-right">
                    {item.objectData.Status === 'pending' && <button onClick={() => handleMarkDone(item)} className="text-green-600 mr-3">Selesai</button>}
                    <button onClick={() => handleDelete(item.objectId)} className="text-red-600">Hapus</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  } catch (error) {
    console.error('OrderManager error:', error);
    return null;
  }
}