function TestimonialSection({ loading }) {
  try {
    const [currentIndex, setCurrentIndex] = React.useState(0);
    const [testimonials, setTestimonials] = React.useState([]);
    const [isLoadingData, setIsLoadingData] = React.useState(true);

    React.useEffect(() => {
      loadTestimonials();
    }, []);

    const loadTestimonials = async () => {
      const result = await trickleListObjects('testimonial', 100, true);
      const activeItems = result.items
        .filter(t => t.objectData.Status === 'active')
        .map(t => ({
          name: t.objectData.Name,
          company: t.objectData.Company ?? "",
          rating: t.objectData.Rating ?? 5,
          text: t.objectData.Message,
          avatar: t.objectData.Avatar || "https://i.pravatar.cc/150?u=" + t.objectId
        }));

      setTestimonials(activeItems);
      setIsLoadingData(false);
    };

    const nextSlide = () => setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    const prevSlide = () => setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

    const showSkeleton = loading || isLoadingData;

    return (
      <section id="testimonials" className="py-20 bg-white" data-name="testimonial-section" data-file="components/TestimonialSection.js">
        <div className="container mx-auto px-6">

          {/* Title */}
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Kata Klien Kami</h2>
            <p className="text-xl text-gray-600">Kepercayaan klien adalah prioritas kami</p>
          </div>

          <div className="max-w-4xl mx-auto relative">
            {showSkeleton ? (
              /* SKELETON LOADING */
              <div className="bg-gray-50 rounded-2xl p-12 text-center">
                <div className="w-20 h-20 bg-gray-200 rounded-full mx-auto mb-6 skeleton-shine"></div>
                <div className="h-6 w-3/4 mx-auto bg-gray-200 rounded mb-4 skeleton-shine"></div>
                <div className="h-4 w-1/2 mx-auto bg-gray-200 rounded mb-6 skeleton-shine"></div>
                <div className="h-4 w-full bg-gray-200 rounded mb-2 skeleton-shine"></div>
                <div className="h-4 w-5/6 mx-auto bg-gray-200 rounded skeleton-shine"></div>
              </div>
            ) : testimonials.length === 0 ? (
              /* NO DATA */
              <div className="bg-gray-50 rounded-2xl p-12 text-center text-gray-500">
                Belum ada testimoni aktif.
              </div>
            ) : (
              /* TESTIMONIAL CARD */
              <div className="bg-gray-50 rounded-2xl p-12 text-center">

                <img
                  src={testimonials[currentIndex].avatar}
                  alt={testimonials[currentIndex].name}
                  className="w-20 h-20 rounded-full mx-auto mb-6 border-4 border-white shadow-lg"
                />

                <div className="flex justify-center gap-1 mb-4">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <div key={i} className="icon-star text-xl text-yellow-400"></div>
                  ))}
                </div>

                <p className="text-xl text-gray-700 mb-6 italic leading-relaxed">
                  "{testimonials[currentIndex].text}"
                </p>

                <h4 className="text-lg font-bold text-gray-900">
                  {testimonials[currentIndex].name}
                </h4>

                <p className="text-[var(--primary-color)] font-semibold">
                  {testimonials[currentIndex].company}
                </p>

              </div>
            )}

            {/* ARROWS */}
            {!showSkeleton && testimonials.length > 1 && (
              <div className="flex justify-center gap-4 mt-8">
                <button
                  onClick={prevSlide}
                  className="w-12 h-12 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center hover:border-[var(--primary-color)] hover:text-[var(--primary-color)] transition"
                >
                  <div className="icon-chevron-left text-xl"></div>
                </button>

                <button
                  onClick={nextSlide}
                  className="w-12 h-12 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center hover:border-[var(--primary-color)] hover:text-[var(--primary-color)] transition"
                >
                  <div className="icon-chevron-right text-xl"></div>
                </button>
              </div>
            )}
          </div>
        </div>
      </section>
    );

  } catch (error) {
    console.error('TestimonialSection component error:', error);
    return null;
  }
}

