function Dashboard({ onNavigate }) {
  try {
    const [stats, setStats] = React.useState({ portfolio: 0, testimonial: 0, package: 0, order: 0 });

    React.useEffect(() => {
      loadStats();
    }, []);

    const loadStats = async () => {
      try {
        const [p, t, pkg, o] = await Promise.all([
          trickleListObjects('portfolio', 100),
          trickleListObjects('testimonial', 100),
          trickleListObjects('package', 100),
          trickleListObjects('order', 100)
        ]);
        setStats({
          portfolio: p.items.length,
          testimonial: t.items.length,
          package: pkg.items.length,
          order: o.items.filter(x => x.objectData.Status === 'pending').length
        });
      } catch (error) {
        console.error('Error loading stats:', error);
      }
    };

    const cards = [
      { title: 'Portfolio', count: stats.portfolio, icon: 'briefcase', color: 'blue', view: 'portfolio' },
      { title: 'Testimoni', count: stats.testimonial, icon: 'message-square', color: 'green', view: 'testimonial' },
      { title: 'Paket', count: stats.package, icon: 'package', color: 'purple', view: 'package' },
      { title: 'Order Pending', count: stats.order, icon: 'shopping-cart', color: 'red', view: 'order' }
    ];

    return (
      <div>
        <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {cards.map(card => (
            <div key={card.title} onClick={() => onNavigate(card.view)} className="bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition cursor-pointer">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 bg-${card.color}-100 rounded-lg flex items-center justify-center`}>
                  <div className={`icon-${card.icon} text-xl text-${card.color}-600`}></div>
                </div>
                <span className="text-3xl font-bold text-gray-900">{card.count}</span>
              </div>
              <h3 className="text-gray-600">{card.title}</h3>
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('Dashboard error:', error);
    return null;
  }
}