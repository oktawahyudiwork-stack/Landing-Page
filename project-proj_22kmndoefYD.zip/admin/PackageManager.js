function PackageManager() {
  try {
    const [items, setItems] = React.useState([]);
    const [modal, setModal] = React.useState({ open: false, item: null });

    React.useEffect(() => {
      loadItems();
    }, []);

    const loadItems = async () => {
      const result = await trickleListObjects('package', 100, true);
      setItems(result.items);
    };

    const handleDelete = async (id) => {
      if (confirm('Hapus paket ini?')) {
        await trickleDeleteObject('package', id);
        loadItems();
      }
    };

    const handleSave = async (data) => {
      if (modal.item) {
        await trickleUpdateObject('package', modal.item.objectId, data);
      } else {
        await trickleCreateObject('package', data);
      }
      setModal({ open: false, item: null });
      loadItems();
    };

    return (
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Paket</h2>
          <button onClick={() => setModal({ open: true, item: null })} className="px-4 py-2 gradient-bg text-white rounded-lg">Tambah</button>
        </div>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left">Nama</th>
                <th className="px-6 py-3 text-left">Harga</th>
                <th className="px-6 py-3 text-left">Status</th>
                <th className="px-6 py-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item.objectId} className="border-t">
                  <td className="px-6 py-4">{item.objectData.Name}</td>
                  <td className="px-6 py-4">{item.objectData.Price}</td>
                  <td className="px-6 py-4"><span className={`px-2 py-1 rounded text-sm ${item.objectData.Status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100'}`}>{item.objectData.Status}</span></td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => setModal({ open: true, item })} className="text-blue-600 mr-3">Edit</button>
                    <button onClick={() => handleDelete(item.objectId)} className="text-red-600">Hapus</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {modal.open && <FormModal type="package" item={modal.item} onClose={() => setModal({ open: false, item: null })} onSave={handleSave} />}
      </div>
    );
  } catch (error) {
    console.error('PackageManager error:', error);
    return null;
  }
}