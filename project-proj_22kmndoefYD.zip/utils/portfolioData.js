function getPortfolioData() {
  return [
    {
      id: 'ecommerce-fashion',
      title: 'Fashion E-Commerce Platform',
      category: 'Web Development',
      image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600',
      description: 'Platform e-commerce lengkap untuk brand fashion dengan sistem pembayaran terintegrasi dan management inventory real-time.',
      techStack: ['React', 'Node.js', 'MongoDB', 'Stripe'],
      features: ['Multi-vendor support', 'Real-time inventory', 'Payment gateway integration', 'Admin dashboard', 'Mobile responsive'],
      caseStudy: 'Brand fashion lokal meningkatkan penjualan online mereka dengan platform yang mudah digunakan dan aman.',
      results: [
        { value: '300%', label: 'Peningkatan Penjualan' },
        { value: '50K+', label: 'Pengguna Aktif' },
        { value: '99.9%', label: 'Uptime' }
      ]
    },
    {
      id: 'delivery-app',
      title: 'Food Delivery Mobile App',
      category: 'Mobile Development',
      image: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?w=600',
      description: 'Aplikasi mobile delivery makanan dengan tracking real-time dan sistem rating restoran.',
      techStack: ['React Native', 'Firebase', 'Google Maps API', 'Node.js'],
      features: ['Real-time GPS tracking', 'Push notifications', 'In-app payment', 'Rating & review system', 'Order history'],
      caseStudy: 'Startup delivery makanan berhasil melayani ribuan pesanan per hari dengan aplikasi yang stabil dan user-friendly.',
      results: [
        { value: '10K+', label: 'Download' },
        { value: '4.8/5', label: 'Rating' },
        { value: '95%', label: 'User Retention' }
      ]
    },
    {
      id: 'corporate-website',
      title: 'Corporate Website Redesign',
      category: 'UI/UX Design',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600',
      description: 'Redesign website corporate dengan fokus pada user experience dan konversi yang lebih tinggi.',
      techStack: ['Figma', 'React', 'TailwindCSS', 'Framer Motion'],
      features: ['Modern UI design', 'SEO optimized', 'Fast loading speed', 'Contact form integration', 'Blog system'],
      caseStudy: 'Perusahaan teknologi meningkatkan lead generation dengan website yang lebih profesional dan mudah dinavigasi.',
      results: [
        { value: '150%', label: 'Lead Increase' },
        { value: '2.5s', label: 'Load Time' },
        { value: '40%', label: 'Bounce Rate Drop' }
      ]
    }
  ];
}