function FloatingWhatsApp() {
  try {
    return (
      <a href="https://wa.me/6289675080104" target="_blank" rel="noopener noreferrer" className="fixed bottom-6 left-6 w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-lg hover:bg-green-600 transition z-40" data-name="floating-whatsapp" data-file="components/FloatingWhatsApp.js">
        <div className="icon-message-circle text-2xl text-white"></div>
      </a>
    );
  } catch (error) {
    console.error('FloatingWhatsApp component error:', error);
    return null;
  }
}