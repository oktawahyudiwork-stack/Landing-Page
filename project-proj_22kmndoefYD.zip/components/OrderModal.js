function OrderModal({ package: pkg, onClose }) {
  try {
    const [formData, setFormData] = React.useState({
      name: '', email: '', whatsapp: '', notes: ''
    });

    const handleSubmit = async (e) => {
      e.preventDefault();
      try {
        await trickleCreateObject('order', {
          CustomerName: formData.name,
          Email: formData.email,
          WhatsApp: formData.whatsapp,
          PackageName: pkg.objectData.Name,
          Notes: formData.notes,
          Status: 'pending'
        });
        const message = `Halo Almira Teknologi, saya ingin memesan paket ${pkg.objectData.Name}. Nama: ${formData.name}, WA: ${formData.whatsapp}, Catatan: ${formData.notes}`;
        window.open(`https://wa.me/6289675080104?text=${encodeURIComponent(message)}`, '_blank');
        onClose();
      } catch (error) {
        alert('Terjadi kesalahan, silakan coba lagi');
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4" onClick={onClose} data-name="order-modal" data-file="components/OrderModal.js">
        <div className="bg-white rounded-xl p-8 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900">Order Paket</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <div className="icon-x text-xl"></div>
            </button>
          </div>
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <p className="font-semibold text-gray-900">{pkg.objectData.Name}</p>
            <p className="text-[var(--primary-color)] font-bold">{pkg.objectData.Price}</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="text" placeholder="Nama Lengkap" required className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
            <input type="email" placeholder="Email" required className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
            <input type="tel" placeholder="Nomor WhatsApp" required className="w-full px-4 py-2 border border-gray-300 rounded-lg" value={formData.whatsapp} onChange={(e) => setFormData({...formData, whatsapp: e.target.value})} />
            <textarea placeholder="Catatan (optional)" className="w-full px-4 py-2 border border-gray-300 rounded-lg" rows="3" value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})}></textarea>
            <button type="submit" className="w-full py-3 gradient-bg text-white rounded-lg hover:opacity-90">
              Kirim ke WhatsApp
            </button>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('OrderModal component error:', error);
    return null;
  }
}