function Footer() {
  try {
    return (
      <footer className="bg-gray-900 text-white py-12" data-name="footer" data-file="components/Footer.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img src="https://app.trickle.so/storage/public/images/usr_17bb8c8758000001/485284ef-4b09-437c-bb19-5dc83babb4be.png" alt="Almira Teknologi Logo" className="w-10 h-10 object-contain" />
                <span className="text-xl font-bold">Almira Teknologi</span>
              </div>

              <p className="text-gray-400">Solusi digital terbaik untuk bisnis Anda</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Kontak</h4>
              <p className="text-gray-400 mb-2">WhatsApp: 089675080104</p>
              <p className="text-gray-400">Email: info@almiratek.com</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Layanan</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Development Website</li>
                <li>Development Mobile Apps</li>
                <li>Design UI/UX</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Almira Teknologi. All rights reserved.</p>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}