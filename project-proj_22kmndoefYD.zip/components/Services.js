function Services() {
  try {
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      setTimeout(() => setLoading(false), 800);
    }, []);

    const services = [
      { icon: 'globe', title: 'Development Website', desc: 'Website profesional dan responsif untuk bisnis Anda' },
      { icon: 'smartphone', title: 'Development Mobile Apps', desc: 'Aplikasi mobile Android & iOS berkualitas tinggi' },
      { icon: 'palette', title: 'Design UI/UX', desc: 'Desain antarmuka modern dan user-friendly' }
    ];

    return (
      <section id="services" className="py-20 bg-gray-50" data-name="services" data-file="components/Services.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Layanan Kami</h2>
            <p className="text-gray-600 text-lg">Solusi digital terlengkap untuk kesuksesan bisnis Anda</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {loading ? (
              Array(3).fill(0).map((_, i) => <SkeletonCard key={i} />)
            ) : (
              services.map((service, idx) => (
                <div key={idx} className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition">
                  <div className="w-14 h-14 gradient-bg rounded-xl flex items-center justify-center mb-4">
                    <div className={`icon-${service.icon} text-2xl text-white`}></div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600">{service.desc}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Services component error:', error);
    return null;
  }
}