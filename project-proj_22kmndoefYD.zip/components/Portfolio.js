function PortfolioSection({ loading }) {
  try {
    const projects = getPortfolioData();

    const handleProjectClick = (projectId) => {
      window.location.href = `portfolio-detail.html?id=${projectId}`;
    };

    return (
      <section id="portfolio" className="py-20 bg-gray-50" data-name="portfolio-section" data-file="components/PortfolioSection.js">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Portfolio Kami</h2>
            <p className="text-xl text-gray-600">Proyek-proyek yang telah kami kerjakan dengan sukses</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div 
                key={index} 
                onClick={() => !loading && handleProjectClick(project.id)}
                className="group rounded-2xl overflow-hidden bg-white hover:shadow-2xl transition cursor-pointer"
              >
                {loading ? (
                  <>
                    <div className="h-64 bg-gray-200 skeleton-shine"></div>
                    <div className="p-6">
                      <div className="h-6 w-3/4 bg-gray-200 rounded mb-3 skeleton-shine"></div>
                      <div className="h-4 w-1/2 bg-gray-200 rounded skeleton-shine"></div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="h-64 overflow-hidden">
                      <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{project.title}</h3>
                      <p className="text-[var(--primary-color)] font-semibold">{project.category}</p>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('PortfolioSection component error:', error);
    return null;
  }
}
