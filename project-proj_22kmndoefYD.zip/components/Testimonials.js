function Testimonials() {
  try {
    const [testimonials, setTestimonials] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [current, setCurrent] = React.useState(0);

    React.useEffect(() => {
      loadTestimonials();
    }, []);

    const loadTestimonials = async () => {
      try {
        const result = await trickleListObjects('testimonial', 100, true);
        setTestimonials(result.items.filter(t => t.objectData.Status === 'active'));
      } catch (error) {
        console.error('Error loading testimonials:', error);
      } finally {
        setLoading(false);
      }
    };

    const next = () => setCurrent((current + 1) % testimonials.length);
    const prev = () => setCurrent(current === 0 ? testimonials.length - 1 : current - 1);

    if (loading) return <div className="py-20"><SkeletonCard /></div>;

    return (
      <section id="testimonials" className="py-20 bg-gray-50" data-name="testimonials" data-file="components/Testimonials.js">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Testimoni Klien</h2>
            <p className="text-gray-600 text-lg">Apa kata klien tentang layanan kami</p>
          </div>
          {testimonials.length > 0 && (
            <div className="bg-white p-8 rounded-xl shadow-sm relative">
              <div className="flex items-center mb-6">
                <img src={testimonials[current].objectData.Photo} alt={testimonials[current].objectData.Name} className="w-16 h-16 rounded-full mr-4" />
                <div>
                  <h4 className="font-bold text-gray-900">{testimonials[current].objectData.Name}</h4>
                </div>
              </div>
              <p className="text-gray-600 text-lg italic mb-6">"{testimonials[current].objectData.Content}"</p>
              <div className="flex justify-center space-x-4">
                <button onClick={prev} className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
                  <div className="icon-chevron-left text-gray-600"></div>
                </button>
                <button onClick={next} className="w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
                  <div className="icon-chevron-right text-gray-600"></div>
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    );
  } catch (error) {
    console.error('Testimonials component error:', error);
    return null;
  }
}