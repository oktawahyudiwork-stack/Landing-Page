function PricingSection({ loading }) {
  try {
    const WA_NUMBER = "6289675080104"; // nomor tujuan

    const sendToWhatsApp = (plan) => {
      // Format message
      const message = `
Halo! Saya ingin memesan layanan:

Paket: Website Development - ${plan.name}
Harga: Rp ${plan.price}

Nama: 
Email: 
Nomor WA: 

Catatan:
`;

      const url = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank");
    };

    const plans = [
      { name: 'Basic', price: '5.000.000', features: ['Website Responsif', 'Desain Custom', '5 Halaman', 'SEO Basic', 'Support 3 Bulan'], popular: false },
      { name: 'Professional', price: '15.000.000', features: ['Website + Mobile App', 'Desain Premium UI/UX', '10 Halaman', 'SEO Advanced', 'CMS Integration', 'Support 6 Bulan'], popular: true },
      { name: 'Enterprise', price: '35.000.000', features: ['Full Stack Solution', 'Custom Development', 'Unlimited Halaman', 'SEO Expert', 'Database Complex', 'API Integration', 'Support 1 Tahun'], popular: false }
    ];

    return (
      <section id="pricing" className="py-20 bg-white" data-name="pricing-section">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Paket Harga</h2>
            <p className="text-xl text-gray-600">Pilih paket yang sesuai dengan kebutuhan bisnis Anda</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <div key={index} className={`rounded-2xl p-8 ${plan.popular ? 'gradient-bg text-white shadow-2xl scale-105' : 'bg-gray-50 border-2 border-gray-100'}`}>
                {loading ? (
                  <>
                    <div className={`h-8 w-1/2 ${plan.popular ? 'bg-white/20' : 'bg-gray-200'} rounded-lg mb-4 skeleton-shine`}></div>
                    <div className={`h-12 w-3/4 ${plan.popular ? 'bg-white/20' : 'bg-gray-200'} rounded-lg mb-6 skeleton-shine`}></div>
                    <div className="space-y-3 mb-8">
                      {[1,2,3,4].map(i => <div key={i} className={`h-4 w-full ${plan.popular ? 'bg-white/20' : 'bg-gray-200'} rounded skeleton-shine`}></div>)}
                    </div>
                    <div className={`h-12 w-full ${plan.popular ? 'bg-white/20' : 'bg-gray-200'} rounded-xl skeleton-shine`}></div>
                  </>
                ) : (
                  <>
                    {plan.popular && <div className="text-sm font-semibold text-white/90 mb-2">PALING POPULER</div>}
                    <h3 className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-white' : 'text-gray-900'}`}>{plan.name}</h3>
                    <div className="mb-6">
                      <span className={`text-4xl font-bold ${plan.popular ? 'text-white' : 'text-gray-900'}`}>Rp {plan.price}</span>
                      <span className={plan.popular ? 'text-white/80' : 'text-gray-600'}> /proyek</span>
                    </div>
                    <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <div className={`icon-check text-xl ${plan.popular ? 'text-white' : 'text-[var(--primary-color)]'} mt-0.5`}></div>
                          <span className={plan.popular ? 'text-white/90' : 'text-gray-700'}>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <button 
                      onClick={() => sendToWhatsApp(plan)}
                      className={`w-full py-3 rounded-xl font-semibold transition ${plan.popular ? 'bg-white text-[var(--primary-color)] hover:shadow-xl' : 'gradient-bg text-white hover:shadow-lg'}`}
                    >
                      Hubungi via WhatsApp
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('PricingSection component error:', error);
    return null;
  }
}

