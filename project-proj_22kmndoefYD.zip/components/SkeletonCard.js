function SkeletonCard() {
  try {
    return (
      <div className="bg-white p-8 rounded-xl shadow-sm" data-name="skeleton-card" data-file="components/SkeletonCard.js">
        <div className="w-14 h-14 shimmer rounded-xl mb-4"></div>
        <div className="h-6 shimmer rounded mb-3 w-3/4"></div>
        <div className="h-4 shimmer rounded w-full"></div>
      </div>
    );
  } catch (error) {
    console.error('SkeletonCard component error:', error);
    return null;
  }
}