function Header() {
  try {
    const scrollToSection = (id) => {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    };

    return (
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img src="https://app.trickle.so/storage/public/images/usr_17bb8c8758000001/485284ef-4b09-437c-bb19-5dc83babb4be.png" alt="Almira Teknologi Logo" className="w-10 h-10 object-contain" />
              <span className="text-xl font-bold text-gray-900">Almira Teknologi</span>
            </div>

            <nav className="hidden md:flex space-x-8">
              <button onClick={() => scrollToSection('services')} className="text-gray-600 hover:text-[var(--primary-color)]">Layanan</button>
              <button onClick={() => scrollToSection('portfolio')} className="text-gray-600 hover:text-[var(--primary-color)]">Portfolio</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-gray-600 hover:text-[var(--primary-color)]">Testimoni</button>
              <button onClick={() => scrollToSection('packages')} className="text-gray-600 hover:text-[var(--primary-color)]">Paket</button>
            </nav>
            <a href="https://wa.me/6289675080104" target="_blank" rel="noopener noreferrer" className="px-6 py-2 gradient-bg text-white rounded-lg hover:opacity-90">
              Konsultasi Gratis
            </a>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}