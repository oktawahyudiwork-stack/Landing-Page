function Hero() {
  try {
    return (
      <section className="pt-32 pb-20 gradient-bg" data-name="hero" data-file="components/Hero.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Solusi Digital Cepat & Terjangkau
              </h1>
              <p className="text-xl mb-8 text-white text-opacity-90">
                Kami membantu bisnis Anda berkembang dengan layanan website, mobile apps, dan UI/UX design profesional
              </p>
              <a 
                href="https://wa.me/6289675080104"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-8 py-3 bg-white text-[var(--primary-color)] rounded-lg font-semibold hover:shadow-lg"
              >
                Konsultasi Gratis
              </a>
            </div>

            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=600"
                alt="Digital Solutions"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}
