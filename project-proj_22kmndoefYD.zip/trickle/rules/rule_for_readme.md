When project updates

- Check if README.md needs to be updated
- Update README.md if new features, pages, or major changes are added
- Keep README.md concise and up-to-date with current project state