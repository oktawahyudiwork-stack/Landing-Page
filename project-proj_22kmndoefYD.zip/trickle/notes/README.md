# Almira Teknologi Website

Website software house lengkap dengan landing page dan admin panel untuk mengelola konten.

## Fitur Utama

### Landing Page
- Hero section dengan CTA WhatsApp
- 3 Layanan utama (Website, Mobile Apps, UI/UX Design)
- Portfolio dengan modal detail
- Testimoni carousel
- Paket pricing dengan form order
- Floating WhatsApp button
- Skeleton loading untuk UX yang lebih baik

### Admin Panel (`admin.html`)
- Dashboard dengan statistik
- CRUD Portfolio
- CRUD Testimoni
- CRUD Paket Layanan
- Order Management

## Database Trickle
- `portfolio` - Menyimpan data portfolio
- `testimonial` - Menyimpan data testimoni
- `package` - Menyimpan data paket layanan
- `order` - Menyimpan data order pelanggan

## Kontak WhatsApp
Semua tombol CTA mengarah ke: https://wa.me/6289675080104

## Teknologi
- React 18
- TailwindCSS
- Lucide Icons
- Trickle Database