function AdminApp() {
  try {
    const [currentView, setCurrentView] = React.useState('dashboard');

    const renderView = () => {
      switch(currentView) {
        case 'dashboard': return <Dashboard onNavigate={setCurrentView} />;
        case 'portfolio': return <PortfolioManager />;
        case 'testimonial': return <TestimonialManager />;
        case 'package': return <PackageManager />;
        case 'order': return <OrderManager />;
        default: return <Dashboard onNavigate={setCurrentView} />;
      }
    };

    return (
      <div className="min-h-screen bg-gray-50">
        <AdminHeader currentView={currentView} onNavigate={setCurrentView} />
        <div className="max-w-7xl mx-auto px-4 py-8">
          {renderView()}
        </div>
      </div>
    );
  } catch (error) {
    console.error('AdminApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AdminApp />);